from bio_embeddings.embed import ( ESM1bEmbedder, BeplerEmbedder, ProtTransT5BFDEmbedder, CPCProtEmbedder, ESMEmbedder,
                                  ESM1vEmbedder, FastTextEmbedder, GloveEmbedder, OneHotEncodingEmbedder, PLUSRNNEmbedder, ProtTransAlbertBFDEmbedder,
                                  ProtTransBertBFDEmbedder, ProtTransT5BFDEmbedder, ProtTransT5XLU50Embedder, ProtTransXLNetUniRef100Embedder,
                                 Word2VecEmbedder)

import numpy as np
from tqdm import tqdm

class UsingBioembeddings:
    """"""
    def __init__( self, dataset=None, id_seq=None, column_seq=None, is_reduced=True, device = None ):
        self.dataset = dataset
        self.id_seq = id_seq
        self.column_seq = column_seq
        self.is_reduced=is_reduced
        self.device = device

        # to save the results
        self.embedder = None
        self.embeddings = None
        self.np_data = None

    def __reducing(self):
        self.np_data = np.zeros(shape=(len(self.dataset), self.embedder.embedding_dimension))
        for idx, embed in tqdm(enumerate(self.embeddings), desc="Reducing embeddings"):
            self.np_data[idx] = self.embedder.reduce_per_protein(embed)

    def __non_reducing(self):
        max_length = 150
        self.np_data = np.zeros(shape=(len(self.dataset), max_length, self.embedder.embedding_dimension))
        for idx, embed in tqdm(enumerate(self.embeddings), desc="Assigning embeddings"):
            embed = np.pad(embed, ((0, max_length - len(embed)), (0, 0)), 'constant')
            self.np_data[idx] = embed
    

    def apply_model(self, model, embedding_dim):
        """"""
        if self.device is not None:
            self.embedder = model(device=self.device, embedding_dimension = embedding_dim)
        else:
            self.embedder = model( embedding_dimension = embedding_dim)
        self.embeddings = self.embedder.embed_many(
            self.dataset[self.column_seq].to_list())
        if self.is_reduced is True:
            self.__reducing()
        else:
            self.__non_reducing()
        return self.np_data

    

if __name__ == "__main__":
    import pandas as pd
    import sys

    df = pd.read_csv(sys.argv[1])
    
    bio_embeddings = UsingBioembeddings(df, "dna_interaction", "sequence", False)

    dict_elements = {
        "bepler" : (BeplerEmbedder, 121),
        "prottrans_t5bdf" : (ProtTransT5BFDEmbedder, 1024),
        "cpcprot" : (CPCProtEmbedder, 512),
        "esme" : (ESMEmbedder, 1280),
        "esm1v" : (ESM1vEmbedder, 1280),
        "fasttext" : (FastTextEmbedder, 512),
        "glove" : (GloveEmbedder, 512),
        "onehot" : (OneHotEncodingEmbedder, 21),
        "plusrnn" : (PLUSRNNEmbedder, 1024),
        "prottrans_albert" : (ProtTransAlbertBFDEmbedder, 4096),
        "prottrans_bert" : (ProtTransBertBFDEmbedder, 1024),
        "prottrans_xlu50" : (ProtTransXLNetUniRef100Embedder, 1024),
        "word2vec" : (Word2VecEmbedder, 512),
    }

    list_error = []
    for element in dict_elements:
        print("Processing element: ", element)

        #try:
        encoded_df = bio_embeddings.apply_model(dict_elements[element][0], dict_elements[element][1])
        print(encoded_df.shape)

        with open("{}{}_X_non_reduced.npy".format(sys.argv[2], element), 'wb') as f:
            np.save(f, encoded_df)
        #except:
        #    list_error.append(element)
        #    pass
    
    print(list_error)